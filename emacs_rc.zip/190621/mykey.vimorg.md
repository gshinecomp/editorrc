*mykey.vimorg*

## My Shortcut keymap for vim-orgmode

### Tag
  **tb** tagbar                    **tl** taglist
### Header
  **<TAB>/<S-TAB>** SubTree Cycle  **\,/\.** Global Cycle
  **\hN|<CR>|<C-S-CR>** InsAbove   **\hh|<S-CR>** InsBelow  **<CR>|<C-CR>** InsBelowChild
  **<<|<C-d>(INS)** PromoteHead    **>>|<C-t>(INS)** DemoteHead
  **<[[** PromoteSubTree           **>]]** DemoteSubTree
  **m{** MoveHeadUp   **m}** MoveHeadDown   **m[[** MoveSubTUp   **m]]** MoveSubTDown
### PlainList
  **\cL|<C-S-CR>** InsAbove   **\cl|<CR>** InsBelow
### Checkbox
  **\cN|<C-S-CR>** InsAbove   **\cn|<CR>** InsBelow   **\cc** Toggle
  **\ct** Rotate TODO at header
### Timestamp
  **\sa** InsActive           **\si** InsInActive     **<C-A>/<C-X>** Increase/Decrease
### Link
  **gil** InsLink             **<F4>|<C-2-LMB>** jump to url

### my vim command
  **\nr**   open selection in a new narrowed window
  **gq}**   reformating paragraph (set fo+=n for numbered list.)
  **<F12>** Redraw syntax


## description in myhelp.org
     - shortcut key map
       
       + cycling
         - <Tab> or <S-Tab>   Subtree cycling: Rotate current subtree among the states
         - \, or \.           Global cycling: Rotate the entire buffer among the
                              states. The same can be achieved by using the
                              keybindings zm and zr.

       + tagbar and tablist
         - tb       tagbar
         - tl       taglist

       + header or heading
         \hN,<CR>,<C-S-CR>  - insert heading above (OrgNewHeadingAboveNormal, OrgNewHeadingAboveInsert)
         \hh,<S-CR>         - insert heading below (OrgNewHeadingBelowNormal, OrgNewHeadingBelowInsert)
         <CR>,<C-CR>        - insert heading below, taking over children (OrgNewHeadingBelowAfterChildrenNormal)
         <C-CR>             - insert heading below, after children (OrgNewHeadingBelowAfterChildrenNormal, OrgNewHeadingBelowAfterChildrenInsert)

       + checkbox, plainlist
         \cl      - create/insert plainlist item below
         \cL      - create/insert plainlist item above
         <CR>     - insert plainlist item below
         <C-S-CR> - insert plainlist item above
         \cc      - toggle checkbox status or (with prefix arg) checkbox
         \cn      - create/insert checkbox item below
         \cN      - create/insert checkbox item above

       + rotate current TODO/DONE items
         \ct      - Rotate the TODO state of the current item among.
                     ,-> (unmarked) -> TODO -> DONE --.
                     '--------------------------------'

       + auto calculate percent for to-do checkbox
         - add =TODO= for items and add [33%] at end

       + gil      insert link

       + timestamp
         \sa      insert active timestamp
         \si      insert inactive timestamp
         C-A or C-X     increase/decrease by speeddating plugin

       + item move / promote / demote
         << or <C-d>(insert mode)   Promote current heading by one level.
         >> or <C-t>(insert mode)   Demote current heading by one level.
         <[[            Promote the current subtree by one level.
         >]]            Demote the current subtree by one level.
         m{             Move heading up (swap with previous/next subtree of
                        same level).
         m}             Move heading down (swap with previous/next subtree of
                        same level).
         m[[            Move subtree up (swap with previous/next subtree of
                        same level).
         m]]            Move subtree down (swap with previous/next subtree of
                        same level).

## Shortcut keymap for eMacs
    - switch buffer	C-x b
    - open buffer list	C-x C-b
	d|<DEL>|C-d	mark to delete
	s	mart to save
	u|U	remove all flags current|all
	x	execute flag action
    - read single expression and eval it	M-:
    - eval the defun	C-M-x | M-x eval-defun
    - eval the region	M-x eval-region
    - eval expression before point	C-x C-e
    - erase-buffer	C-x h C-w
    - split two windows	C-x 2
    - mark		C-<SPC>
    - open file	C-x C-f
    - save current file	C-x C-s | save-buffer
    - enable emacs interaction mode	M-x lisp-interaction-mode
    - change buffer font	S-mouse1 | M-x menu-set-font
    - load-theme	M-x load-theme
    - increase/decrease font size	C-x, C-=|C--
    - ielm	M-x ielm
    - search word	C-s|C-r
    - undo		C- _ | C-x u | C-/
    - kill current buffer	C-x k
    - quit buffer	q
    - close current window (split pane) C-x 0
    - escape command	Esc Esc Esc | C-g
    - see the docstring	C-h f functionName
    - see the variable	C-h v variableName

## Shortcut keymap for eMacs org-mode
    - heading
       - Next|Prev heading	C-c C-n|C-p
       - Outline up heading	C-c C-u
       - new heading
          - new the same level heading	C-<RET>
          - move heading level	M-<LEFT>|M-<RIGHT>
          - cut sub-tree	C-c C-x C-w
          - org-forward-same-level	C-c C-f|C-b
          - org-goto(multi-func)	C-c C-j /
       - plain list
          - cyle the bullets	C-c -
          - turn to headline	C-c *
          - turn all subtree to headline	C-c C-*
          - sort plain list	C-c ^
          - check the checkbox	C-c C-c
          - jump plain list	S-arrow
          - move plain list	M-arrow
       - insert|edit link	C-c C-l
          - open link	C-c C-o
          - open link without emacs	C-u C-u C-c C-o
    - rectangle
       - M-x string-insert-rectangle

## command for eMacs
    - (print "hello" (get-buffer-create "foo")
      - (print "world" (get-buffer "foo")
    - (with-output-to-temp-buffer "foo2" (print "hello"))
    - (with-help-window "foo3"  (print "world"))
    - (message "hello")
    - (subrp (symbol-function 'cond))  ;; check built-in primitive
    - lambda
      (defun aaa (n) `(lambda (x) (+ x ,n)))
      (aaa 5)
      (funcall (aaa 5) 3)
    - (eval-when-compile (require 'cl))
      (defun got-what (x)
        (ecase x
               ((nil) :got-nil)
               ((t) :got-t)
               ((foo bar) :got-foo)))
      (got-what 'nil)
      (got-what 'foo)
    - (require 'cl)
      (defun ml (mon)
        (case mon
              ((jan mar) 31)
              (feb 28)
              (otherwise "unk")))
      (ml 'jan)

